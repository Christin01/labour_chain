<?php
include 'menu.php';
include '../conection.php';
ob_start();
?>
<!---->

<!---->
<div class="content">
	 <div class="container">
		 <div class="slider">
				<ul class="rslides" id="slider1">
				  <li><img src="images/banner2.jpg" alt=""></li>
				  <li><img src="images/banner3.jpg" alt=""></li>
                                  <li><img src="images/banner1.jpg" alt=""></li>
				</ul>
		 </div>
	 </div>
</div>
<div class="bottom_content">
	 <div class="container">
             
		 <div class="sofas">
			 <div class="col-md-6 sofa-grid">
				 <img src="images/t1.jpg" alt=""/>
				 <h3>100% PROTECTED AND SECURE</h3>
				 
			 </div>
			 <div class="col-md-6 sofa-grid sofs">
                             <img src="images/t2.jpg" alt=""/>
				 <h3>MOVE MONEY ANYTIME ANYWHERE</h3>
				 
			 </div>
                     
			 <div class="clearfix"></div>
		 </div>
              
             
	 </div>

</div>


<!---->

<?php
include 'footer.php';
?>